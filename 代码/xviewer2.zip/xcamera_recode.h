#pragma once
#include <string>
#include "xtool.h"
class XCameraRecode:public XThread
{
public:
    void set_rtsp_url(std::string url)
    {
        rtsp_url_ = url;
    }
    void set_save_path(std::string s)
    {
        save_path_ = s;
    }
private:
    void Main();
    std::string rtsp_url_;
    std::string save_path_;
};

