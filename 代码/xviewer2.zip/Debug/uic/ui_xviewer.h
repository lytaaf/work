/********************************************************************************
** Form generated from reading UI file 'xviewer.ui'
**
** Created by: Qt User Interface Compiler version 5.10.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_XVIEWER_H
#define UI_XVIEWER_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QListWidget>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_XViewerClass
{
public:
    QWidget *head;
    QWidget *logo;
    QWidget *head_button;
    QPushButton *min;
    QPushButton *max;
    QPushButton *close;
    QPushButton *normal;
    QWidget *body;
    QWidget *left;
    QListWidget *cam_list;
    QPushButton *add_cam;
    QPushButton *set_cam;
    QPushButton *del_cam;
    QWidget *cams;

    void setupUi(QWidget *XViewerClass)
    {
        if (XViewerClass->objectName().isEmpty())
            XViewerClass->setObjectName(QStringLiteral("XViewerClass"));
        XViewerClass->resize(799, 600);
        QIcon icon;
        icon.addFile(QStringLiteral(":/XViewer/img/xv.ico"), QSize(), QIcon::Normal, QIcon::Off);
        XViewerClass->setWindowIcon(icon);
        XViewerClass->setStyleSheet(QLatin1String("#head\n"
"{\n"
"background-color:#3c3c3c;\n"
"}\n"
"#logo\n"
"{\n"
"background-image: url(:/XViewer/img/logo_150_40.png);\n"
"}\n"
"#min\n"
"{\n"
"background-image: url(:/XViewer/img/min.png);\n"
"}\n"
"#max\n"
"{\n"
"background-image: url(:/XViewer/img/max.png);\n"
"}\n"
"#normal\n"
"{\n"
"background-image: url(:/XViewer/img/normal.png);\n"
"}\n"
"#close\n"
"{\n"
"background-image: url(:/XViewer/img/close.png);\n"
"}\n"
"#body\n"
"{\n"
"background-color:#212121;\n"
"}\n"
"#left\n"
"{\n"
"background-color:#252525;\n"
"}\n"
"#cams\n"
"{\n"
"background-color:#1e1e1e;\n"
"}\n"
""));
        head = new QWidget(XViewerClass);
        head->setObjectName(QStringLiteral("head"));
        head->setGeometry(QRect(0, 0, 800, 60));
        head->setMaximumSize(QSize(16777215, 60));
        logo = new QWidget(head);
        logo->setObjectName(QStringLiteral("logo"));
        logo->setGeometry(QRect(0, 0, 151, 41));
        head_button = new QWidget(head);
        head_button->setObjectName(QStringLiteral("head_button"));
        head_button->setGeometry(QRect(610, 10, 181, 31));
        min = new QPushButton(head_button);
        min->setObjectName(QStringLiteral("min"));
        min->setGeometry(QRect(40, 10, 20, 20));
        min->setFlat(true);
        max = new QPushButton(head_button);
        max->setObjectName(QStringLiteral("max"));
        max->setGeometry(QRect(90, 10, 20, 20));
        max->setFlat(true);
        close = new QPushButton(head_button);
        close->setObjectName(QStringLiteral("close"));
        close->setGeometry(QRect(140, 10, 20, 20));
        close->setFlat(true);
        normal = new QPushButton(head_button);
        normal->setObjectName(QStringLiteral("normal"));
        normal->setGeometry(QRect(90, 10, 20, 20));
        normal->setFlat(true);
        min->raise();
        close->raise();
        normal->raise();
        max->raise();
        body = new QWidget(XViewerClass);
        body->setObjectName(QStringLiteral("body"));
        body->setGeometry(QRect(0, 60, 771, 451));
        left = new QWidget(body);
        left->setObjectName(QStringLiteral("left"));
        left->setGeometry(QRect(10, 10, 200, 600));
        left->setMaximumSize(QSize(200, 16777215));
        cam_list = new QListWidget(left);
        cam_list->setObjectName(QStringLiteral("cam_list"));
        cam_list->setGeometry(QRect(0, 39, 201, 961));
        cam_list->setDragEnabled(true);
        cam_list->setIconSize(QSize(20, 20));
        add_cam = new QPushButton(left);
        add_cam->setObjectName(QStringLiteral("add_cam"));
        add_cam->setGeometry(QRect(0, 0, 50, 30));
        set_cam = new QPushButton(left);
        set_cam->setObjectName(QStringLiteral("set_cam"));
        set_cam->setGeometry(QRect(70, 0, 50, 30));
        del_cam = new QPushButton(left);
        del_cam->setObjectName(QStringLiteral("del_cam"));
        del_cam->setGeometry(QRect(130, 0, 50, 30));
        cams = new QWidget(body);
        cams->setObjectName(QStringLiteral("cams"));
        cams->setGeometry(QRect(280, 10, 150, 431));
        cams->setMaximumSize(QSize(16777215, 16777215));

        retranslateUi(XViewerClass);
        QObject::connect(close, SIGNAL(clicked()), XViewerClass, SLOT(close()));
        QObject::connect(min, SIGNAL(clicked()), XViewerClass, SLOT(showMinimized()));
        QObject::connect(max, SIGNAL(clicked()), XViewerClass, SLOT(MaxWindow()));
        QObject::connect(normal, SIGNAL(clicked()), XViewerClass, SLOT(NormalWindow()));
        QObject::connect(add_cam, SIGNAL(clicked()), XViewerClass, SLOT(AddCam()));
        QObject::connect(set_cam, SIGNAL(clicked()), XViewerClass, SLOT(SetCam()));
        QObject::connect(del_cam, SIGNAL(clicked()), XViewerClass, SLOT(DelCam()));

        QMetaObject::connectSlotsByName(XViewerClass);
    } // setupUi

    void retranslateUi(QWidget *XViewerClass)
    {
        XViewerClass->setWindowTitle(QApplication::translate("XViewerClass", "XViewer", nullptr));
        min->setText(QString());
        max->setText(QString());
        close->setText(QString());
        normal->setText(QString());
        add_cam->setText(QApplication::translate("XViewerClass", "\346\226\260\345\242\236", nullptr));
        set_cam->setText(QApplication::translate("XViewerClass", "\344\277\256\346\224\271", nullptr));
        del_cam->setText(QApplication::translate("XViewerClass", "\345\210\240\351\231\244", nullptr));
    } // retranslateUi

};

namespace Ui {
    class XViewerClass: public Ui_XViewerClass {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_XVIEWER_H
