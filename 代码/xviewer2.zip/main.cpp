#include "xviewer.h"
#include "xcamera_config.h"
#include<QDebug>
#include <QtWidgets/QApplication>
#include "xcamera_recode.h"

#define TEST_CAM_PATH "test.db"
int main(int argc, char *argv[])
{
#if 0
    XCameraRecode xr;
    xr.set_rtsp_url("rtsp://127.0.0.1:8554/test");
    xr.set_save_path("./test1.mp4");
    xr.Start();
#endif
    //����ʵ������
  /*  auto* xc = XCameraConfig::Instance();
    xc->Load(TEST_CAM_PATH);
    {
        XCameraData cd;
        strcpy(cd.name, "cameral");
        strcpy(cd.save_path, ".\\cameral\\");
        strcpy(cd.url, "rtsp://127.0.0.1:8554/test");
        strcpy(cd.sub_url, "rtsp://127.0.0.1:8554/test");
        xc->Push(cd);
    }

    {
        XCameraData cd;
        strcpy(cd.name, "camera2");
        strcpy(cd.save_path, ".\\cameral2\\");
        strcpy(cd.url, "rtsp://127.0.0.1:8554/test2");
        strcpy(cd.sub_url, "rtsp://127.0.0.1:8554/test2");
        xc->Push(cd);
    }
    int cam_count = xc->cam_size();

    for (int i = 0; i < cam_count; i++)
    {
        auto cam = xc->GetCam(i);
        qDebug() << cam.name ;

    }
    xc->Save(TEST_CAM_PATH);*/
 
    QApplication a(argc, argv);
    XViewer w;
    w.show();
    return a.exec();
}
