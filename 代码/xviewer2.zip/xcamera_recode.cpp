#include "xcamera_recode.h"
#include "xdemux_task.h"
#include "xdecode_task.h"
#include "xmux_task.h"

void XCameraRecode::Main()
{
    XDemuxTask demux;
    XMuxTask mux;
    if (rtsp_url_.empty())
    {
        LOGERROR("open rtsp url faild");
        return;
    }
    //����
    while (!m_bIsExit)
    {
        if (demux.Open(rtsp_url_))
        {
            break;
        }
        MSleep(10);
        continue;
    }
    //����Ƶ����
    auto vpara = demux.CopyVideoPara();
    if (!vpara)
    {
        //������Դ�ͷŵ�����
        demux.Stop();
        return;
    }
    //�������װ ,��ǰ������ֹ��ʱ
    demux.Start();
    auto apara = demux.CopyAudioPara();

    AVCodecParameters* para = nullptr;
    AVRational* timebase = nullptr;

    if (apara)
    {
        para = apara->m_pstPara;
        timebase = apara->m_pstTimeBase;
    }
    if (!mux.Open(save_path_.c_str(), vpara->m_pstPara,
        vpara->m_pstTimeBase, para, timebase))
    {
        LOGERROR("demux CopyVideoPara error");
        demux.Stop();
        mux.Stop();
        return;
    }
    demux.set_next(&mux);
    mux.Start();
    MSleep(3000);
    demux.Stop();
    mux.Stop();
}