#pragma once
#include <QThread>
#include <mutex>
#include <list>
struct AVCodecParameters;
struct AVPacket;
class XDecodec;
class XAudioPlay;
class XResample;

class XAudioThread:public QThread
{
public:
	//��ǰ��Ƶ���ŵ�pts
	long long m_llPts = 0;
	//�򿪣����ܳɹ��������
	virtual bool Open(AVCodecParameters *pstPara, int iSampleRate, int iChannels);
	virtual void Push(AVPacket *pstPacket);
	virtual void Stop();
	virtual void Clear();
	virtual void Close();
	void run();
	XAudioThread();
	virtual ~XAudioThread();

	bool m_bIsPause = false;
	void SetPause(bool bIsPause);
	
	int m_iMaxList = 100;
	bool m_bIsExit = false;
protected:

	std::list<AVPacket*> m_lsPackets;
	std::mutex mux;
	XDecodec *m_clsDecodec = NULL;
	XAudioPlay *m_clsAdoPlay = NULL;
	XResample  *m_clsResample = NULL;

};

