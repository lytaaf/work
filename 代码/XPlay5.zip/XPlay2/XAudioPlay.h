#pragma once
class XAudioPlay
{
public:
	int m_iSampleRate = 44100;
	int m_iSampleSize = 16;
	int m_iChannels = 2;
	//����Ƶ����
	virtual bool Open() = 0;
	virtual void Close() = 0;
	virtual void Clear() = 0;
	virtual long long GetNoPlayMs() = 0;
	virtual bool Write(const unsigned char *pucData, int iDataSize)=0;
	virtual int GetFree() = 0;
	virtual void SetPause(bool bIsPause) = 0;
	static XAudioPlay *Get();
	XAudioPlay();
	virtual ~XAudioPlay();
};

