#pragma once

#include <QtWidgets/QWidget>
#include "ui_XPlay2.h"

class XPlay2 : public QWidget
{
	Q_OBJECT

public:
	XPlay2(QWidget *parent = Q_NULLPTR);
	~XPlay2();
	//��ʱ������������ʾ
	void timerEvent(QTimerEvent *e);

	//���ڳߴ�ı仯
	void resizeEvent(QResizeEvent *e);

	void mouseDoubleClickEvent(QMouseEvent *e);
	void SetPause(bool isPlay);
public slots:
//�ۺ���
	void OpenFile();
	void PlayOrPause();
	void SliderPress();
	void SliderRelease();

private:
	bool m_bIsSliderPress = false;


public:
	Ui::XPlay2Class ui;
};
