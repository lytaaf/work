#include "XDemu.h"
#include <iostream>
extern "C"
{
#include "libavformat\avformat.h"
}
#pragma comment(lib, "avformat.lib")
#pragma comment(lib, "avcodec.lib")
#pragma comment(lib, "avutil.lib")
using namespace std;

static double r2d(AVRational stR)
{
	return (stR.den == 0) ? 0 : ((double)stR.num / (double)stR.den);
}

bool XDemu::IsAudio(AVPacket *pstPacket)
{
	if (NULL == pstPacket)
	{
		return false;
	}
	if (pstPacket->stream_index == m_iVideoStreamID)
		return false;
	return true;
}

bool XDemu::Open(const char *pcUrl)
{
	Close();
	AVDictionary * pstOpts = NULL;
	//����һЩ����
	av_dict_set(&pstOpts, "rtsp_transport", "tcp", 0);
	av_dict_set(&pstOpts, "max_delay", "500", 0);
	//0�����Զ�ѡ������
	m_DemuMux.lock();
	int iRet = avformat_open_input(&m_pstFormCtx, pcUrl, 0, &pstOpts);
	if (0 != iRet)
	{
		char szBuf[1024] = { 0 };
		av_strerror(iRet, szBuf, sizeof(szBuf) - 1);
		std::cout << "avformat_open_input faild" << endl;
		m_DemuMux.unlock();
		return false;
	}

	//��ȡ������Ϣ
	iRet = avformat_find_stream_info(m_pstFormCtx, NULL);
	//��ʱ�� ���Լ����ܵ�ʱ�䳤�� ��ms)
	m_iTotalTime = m_pstFormCtx->duration / (AV_TIME_BASE / 1000);
	cout << "Tolal TIME MS" << m_iTotalTime << endl;
	//��ӡ��Ƶ������ϸ����Ϣ
	av_dump_format(m_pstFormCtx, 0, pcUrl, 0);  

	m_iVideoStreamID = av_find_best_stream(m_pstFormCtx, AVMEDIA_TYPE_VIDEO, -1, -1, NULL, 0);
	AVStream *pstStrem = m_pstFormCtx->streams[m_iVideoStreamID];
	printf("iVideoStreamID = %d, ��Ƶ��Ϣ\n", m_iVideoStreamID);
	cout << "codec_id = " << pstStrem->codecpar->codec_id << endl;
	m_iWid = pstStrem->codecpar->width;
	m_iHei = pstStrem->codecpar->height;
	cout << "format = " << pstStrem->codecpar->format << endl;
	cout << "Wid" << pstStrem->codecpar->width << endl;
	cout << "Hei" << pstStrem->codecpar->height << endl;
	cout << "VdoFps" << r2d(pstStrem->avg_frame_rate) << endl;

	//��ȡ��Ƶ��
	m_iAudioStreamID = av_find_best_stream(m_pstFormCtx, AVMEDIA_TYPE_AUDIO, -1, -1, NULL, 0);
	pstStrem = m_pstFormCtx->streams[m_iAudioStreamID];
    m_iSampleRate = pstStrem->codecpar->sample_rate;
	m_iChannels = pstStrem->codecpar->channels;
	printf("iAudioStreamID = %d, ��Ƶ��Ϣ\n", m_iAudioStreamID);
	cout << "codec_id = " << pstStrem->codecpar->codec_id << endl;
	cout << "format = " << pstStrem->codecpar->format << endl;
	cout << "sample_rate = " << pstStrem->codecpar->sample_rate << endl;
	cout << "channels = " << pstStrem->codecpar->channels << endl;
	//һ֡����  һ�������������� fps = sample_rate / Frame_size
	cout << "Frame_size" << pstStrem->codecpar->frame_size << endl;
	m_DemuMux.unlock();
	return true;
}
AVPacket* XDemu::ReadVideo()
{
	m_DemuMux.lock();
	if (NULL == m_pstFormCtx)
	{
		m_DemuMux.unlock();
		return NULL;
	}

	m_DemuMux.unlock();
	AVPacket *pstPacket = NULL;
	//��ֹ����
	for (int i = 0; i < 20; i++)
	{
		pstPacket = Read();
		if (NULL == pstPacket) break;
		if (pstPacket->stream_index == m_iVideoStreamID)
		{
			break;
		}
		av_packet_free(&pstPacket);
	}

	return pstPacket;
}

//�ռ���Ҫ�������ͷţ��ͷ�AVPacket����Ŀռ������ �ռ� av_packet_free();
AVPacket* XDemu::Read()
{
	m_DemuMux.lock();
	if (NULL == m_pstFormCtx)
	{
		m_DemuMux.unlock();
		return NULL;
	}
	
	AVPacket *pstPacket = NULL;
	pstPacket = av_packet_alloc();

	int iRet = av_read_frame(m_pstFormCtx, pstPacket);
	if (0 != iRet)
	{
		m_DemuMux.unlock();
		av_packet_free(&pstPacket);
		return NULL;
	}

	pstPacket->pts = pstPacket->pts * (1000 * r2d(m_pstFormCtx->streams[pstPacket->stream_index]->time_base));
	pstPacket->dts = pstPacket->dts * (1000 * r2d(m_pstFormCtx->streams[pstPacket->stream_index]->time_base));
	m_DemuMux.unlock();
	cout << pstPacket->pts << " " << flush;
	return pstPacket;
}

void XDemu::Clear()
{
	m_DemuMux.lock();
	if (NULL == m_pstFormCtx)
	{
		m_DemuMux.unlock();
		return ;
	}
	avformat_flush(m_pstFormCtx);


	m_DemuMux.unlock();
	return;
}
void XDemu::Close()
{
	m_DemuMux.lock();
	if (NULL == m_pstFormCtx)
	{
		m_DemuMux.unlock();
		return;
	}
	avformat_close_input(&m_pstFormCtx);
	int m_iTotalTime = 0;
	m_DemuMux.unlock();
	return;
}
#if 1
bool XDemu::Seek(double dbPos)
{
	m_DemuMux.lock();
	if (NULL == m_pstFormCtx)
	{
		m_DemuMux.unlock();
		return false;
	}
	avformat_flush(m_pstFormCtx);
	long long llSeekPos = 0;
	llSeekPos = m_pstFormCtx->streams[m_iVideoStreamID]->duration * dbPos;

	int iRet = av_seek_frame(m_pstFormCtx, m_iVideoStreamID, llSeekPos, AVSEEK_FLAG_BACKWARD | AVSEEK_FLAG_FRAME);
	m_DemuMux.unlock();

	if (iRet < 0)
	{
		return false;
	}
	return true;
}
#endif
//��ȡ��Ƶ�Ĳ��� ���صĿռ���Ҫ���� avcodec_paramters_free
AVCodecParameters* XDemu::CopyVideoPara()
{
	m_DemuMux.lock();
	if (NULL == m_pstFormCtx)
	{
		m_DemuMux.unlock();
		return NULL;
	}
	AVCodecParameters * pstPara = avcodec_parameters_alloc();
	avcodec_parameters_copy(pstPara, m_pstFormCtx->streams[m_iVideoStreamID]->codecpar);

	m_DemuMux.unlock();
	return pstPara;
}
AVCodecParameters* XDemu::CopyAudioPara()
{
	m_DemuMux.lock();
	if (NULL == m_pstFormCtx)
	{
		m_DemuMux.unlock();
		return NULL;
	}

	AVCodecParameters * pstPara = avcodec_parameters_alloc();
	avcodec_parameters_copy(pstPara, m_pstFormCtx->streams[m_iAudioStreamID]->codecpar);

	m_DemuMux.unlock();
	return pstPara;
}
XDemu::XDemu()
{
	//ϣ�����߳�ͬʱ���õ�ʱ�򲻻��������
	static bool bIsFirst = true;

	static  std::mutex dmux;
	dmux.lock();
	if (bIsFirst)
	{
		av_register_all();
		//��ʼ������⣨���Դ� rtsp rtmp http Э�����ý�����Ƶ��
		avformat_network_init();
		bIsFirst = false;
	}
	dmux.unlock();
}


XDemu::~XDemu()
{
}
