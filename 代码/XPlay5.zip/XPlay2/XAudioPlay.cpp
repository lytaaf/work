#include "XAudioPlay.h"
#include <QAudioFormat>
#include <QAudioOutput>
#include <iostream>
#include <mutex>

using namespace std;
class CXAudioPlay :public XAudioPlay
{ 
public:
	std::mutex mtu;
	QAudioOutput *m_pstOut = NULL;
	QIODevice *m_pstIo = NULL;

	virtual long long GetNoPlayMs()
	{
		mtu.lock();
		if (NULL == m_pstOut)
		{
			mtu.unlock();
			return 0;
		}
		long long llPts = 0;
		double  dbSize = m_pstOut->bufferSize() - m_pstOut->bytesFree();
		double dbSecSize = m_iSampleRate * (m_iSampleSize / 8) * m_iChannels;
		//һ����Ƶ�ֽڵĴ�С
		if (dbSecSize <= 0)
		{
			llPts = 0;
		}
		else
		{
			llPts = (dbSize /dbSecSize ) * 1000;
		}
		mtu.unlock();
		return llPts;
	}

	virtual void Clear()
	{
		mtu.lock();
		if (NULL != m_pstIo)
		{
			m_pstIo->reset();
		}

		mtu.unlock();
	}
	virtual void Close()
	{
		mtu.lock();
		if (NULL != m_pstIo)
		{
			m_pstIo->close();
			m_pstIo = NULL;
		}
		if (NULL != m_pstOut)
		{
			m_pstOut->stop();
			delete m_pstOut;
			m_pstOut = NULL;
		}
		mtu.unlock();
	}
	virtual bool Open()
	{
		QAudioFormat stFormat;
		stFormat.setSampleRate(m_iSampleRate);
		stFormat.setSampleSize(m_iSampleSize);
		stFormat.setChannelCount(m_iChannels);
		stFormat.setCodec("audio/pcm");
		stFormat.setByteOrder(QAudioFormat::LittleEndian);
		stFormat.setSampleType(QAudioFormat::UnSignedInt);
		mtu.lock();
		m_pstOut = new QAudioOutput(stFormat);
		m_pstIo = m_pstOut->start();
		mtu.unlock();
		if (NULL != m_pstIo)  return true;
		return true;
	}

	virtual void SetPause(bool bIsPause)
	{
		mtu.lock();
		if (NULL == m_pstOut){
			mtu.unlock();
			return;
		}
		if (bIsPause)
		{
			m_pstOut->suspend();
		}
		else
		{
			m_pstOut->resume();
		}

		mtu.unlock();
	}
	virtual bool Write(const unsigned char *pucData, int iDataSize)
	{
		if ((NULL == pucData) || (iDataSize < 0))
		{
			cout <<"Write : NULL == pucData || (iDataSize < 0" << endl;
			return false;
		}
		mtu.lock();
		if (NULL == m_pstOut || NULL == m_pstIo)
		{
			mtu.unlock();
			return false;
		}
		int iLen = m_pstIo->write((char*)pucData, iDataSize);
		mtu.unlock();
		if (iLen != iDataSize)
		{
			cout << "m_pstIo->write" << endl;
			return false;
		}
		return true;
	}
	virtual int GetFree()
	{
		mtu.lock();
		if (NULL == m_pstOut)
		{
			mtu.unlock();
			return 0;
		}
		int free = m_pstOut->bytesFree();
		mtu.unlock();

		return free;
	}

};
XAudioPlay* XAudioPlay::Get()
{
	static CXAudioPlay clsPlay;
	return &clsPlay;
}

XAudioPlay::XAudioPlay()
{
}


XAudioPlay::~XAudioPlay()
{
}
