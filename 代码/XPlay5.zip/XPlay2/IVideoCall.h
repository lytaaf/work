#pragma once

struct AVFrame;
class IVideoCall
{
public:
	virtual void Init(int iWid, int iHei) = 0;
	virtual void Repaint(AVFrame *pstFrame) = 0;
};

