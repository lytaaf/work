/*******************************************************************************
**                                                                            **
**                     Jiedi(China nanjing)Ltd.                               **
**	               �������Ĳܿ����˴��������Ϊѧϰ�ο�                       **
*******************************************************************************/

/*****************************FILE INFOMATION***********************************
**
** Project       : FFmpeg
** Description   : FFMPEG��Ŀ����ʾ��
** Contact       : xiacaojun@qq.com
**        ����   : http://blog.csdn.net/jiedichina
**		��Ƶ�γ�
**�����ƿ���	http://study.163.com/u/xiacaojun
**��Ѷ����		https://jiedi.ke.qq.com/
**csdnѧԺ		http://edu.csdn.net/lecturer/lecturer_detail?lecturer_id=961
**51ctoѧԺ	    http://edu.51cto.com/lecturer/index/user_id-12016059.html
**�������µ�ffmpeg�汾 http://www.ffmpeg.club
**
**   ffmpeg+qt������ ѧԱȺ ��462249121 ����Ⱥ���ش���ͽ���
**   ΢�Ź��ں�  : jiedi2007
**		ͷ����	 : �Ĳܿ�
**
*******************************************************************************/
//������������������ ѧԱ��Ⱥ462249121���ش���ͽ���




#include "XPlay2.h"
#include <QtWidgets/QApplication>
#include <iostream>
using namespace std;
#include "XDemu.h"
#include "XDecodec.h"
#include "XResample.h"
#include <QThread>
#include "XAudioPlay.h"
#include "XAudioThread.h"
#include "XVideoThread.h"
#include "XDeauxThread.h"
class TestThread :public QThread
{
public:
	XAudioThread at;
	XVideoThread vt;
	void Init()
	{
		char *url = "test.mp4";
		cout << "demux.Open = " << demux.Open(url);


		cout << "at.Open = " << at.Open(demux.CopyAudioPara(), demux.m_iSampleRate, demux.m_iChannels);
		vt.Open(demux.CopyVideoPara(), video, demux.m_iWid, demux.m_iHei);
		at.start();
		vt.start();
	}
	unsigned char *pcm = new unsigned char[1024 * 1024];
	void run()
	{
		for (;;)
		{
			AVPacket *pkt = demux.Read();
			if (demux.IsAudio(pkt))
			{
				at.Push(pkt);
			}
			else
			{
				vt.Push(pkt);
			}
			if (!pkt)
			{
				demux.Seek(0);
			}
		}
	}
	XDemu demux;
	XVideoWidget *video = 0;

};

//v1080.mp4
int main(int argc, char *argv[])
{
	QApplication a(argc, argv);
	XPlay2 w;
	w.show();

	//XDeauxThread dt;
	//char *url = "rtsp://wowzaec2demo.streamlock.net/vod/mp4:BigBuckBunny_115k.mov";
	//char *url2= "test.mp4";
	//dt.Open(url2, w.ui.video);
	//dt.Start();

	return a.exec();
}
