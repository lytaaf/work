#include <iostream>
#include "XAudioThread.h"
#include "XDecodec.h"
#include "XResample.h"
#include "XAudioPlay.h"


using namespace std;

void XAudioThread::Push(AVPacket *pstPacket)
{
	if (NULL == pstPacket) return;
	
	//����
	while (false == m_bIsExit)
	{
		mux.lock();
		if (m_lsPackets.size() < m_iMaxList)
		{
			
			m_lsPackets.push_back(pstPacket);
			cout <<"XAudioThread ::Push" << endl;
			mux.unlock();
			break;
		}
		mux.unlock();
		msleep(1);
	}
}
void XAudioThread::Clear()
{
	mux.lock();
	m_clsDecodec->Clear();
	while (!m_lsPackets.empty())
	{
		AVPacket *pstPacket = m_lsPackets.front();
		XFreePacket(&pstPacket);
		m_lsPackets.pop_front();
	}

	mux.unlock();

	mux.lock();
	if (m_clsAdoPlay) m_clsAdoPlay->Clear();

	mux.unlock();
}
void XAudioThread::Close()
{
	mux.lock();
	m_bIsExit = true;
	wait();
	m_clsDecodec->Close();
	delete m_clsDecodec;
	m_clsDecodec = NULL;
	mux.unlock();
}
void XAudioThread::Stop()
{
	Close();
	if (NULL != m_clsResample)
	{
		m_clsResample->Close();
		mux.lock();
		delete m_clsResample;
		m_clsResample = NULL;
		mux.unlock();
	}
	if (m_clsAdoPlay)
	{
		m_clsAdoPlay->Close();
		mux.lock();
		m_clsAdoPlay = NULL;
		mux.unlock();
	}
}
bool XAudioThread::Open(AVCodecParameters *pstPara ,int iSampleRate, int iChannels)
{
	if (NULL == pstPara) return false;
	mux.lock();

	m_llPts = 0;
	if (NULL  == m_clsDecodec){
		m_clsDecodec = new XDecodec();
	}
	if (NULL == m_clsResample){
		m_clsResample = new XResample();
	}
	if (NULL == m_clsAdoPlay){
		m_clsAdoPlay = XAudioPlay::Get();
	}
	
	bool bRet = true;
	if (false == m_clsDecodec->Open(pstPara)) {
		bRet = false;
		cout << "XAudioThread false == m_clsDecodec->Open" << endl;
	}
	m_clsDecodec->m_bIsAudio = true;
	if (false == m_clsResample->Open(pstPara, false)){
		bRet = false;
		cout << "XAudioThread open m_clsResample->Open false" <<endl;
	}

	m_clsAdoPlay->m_iSampleRate = iSampleRate;
	m_clsAdoPlay->m_iChannels = iChannels;
	if (false == m_clsAdoPlay->Open()) {
		bRet = false;
		cout << "XAudioThread open m_clsAdoPlay->Open() false" << endl;
	}

	//�������Եõ��ͷ�
	mux.unlock();
	cout <<"XAudioThread open success" << endl;
	return bRet;
}


void XAudioThread::SetPause(bool bIsPause)
{
	//mux.lock();
	m_bIsPause = bIsPause;
	if (NULL != m_clsAdoPlay)
		m_clsAdoPlay->SetPause(bIsPause);
	//mux.unlock();
}
void XAudioThread::run()
{
	unsigned char *pucPcm = new unsigned char[1024 * 1024 * 10];

	while (false == m_bIsExit)
	{
		mux.lock();

		if (m_bIsPause)
		{
			mux.unlock();
			msleep(5);
			continue;
		}
		if ((m_lsPackets.empty()) || (NULL == m_clsDecodec) ||
			(NULL == m_clsResample) || (NULL == m_clsAdoPlay))
		{
			mux.unlock();
			msleep(1);
			continue;
		}
		AVPacket *pstPacket = m_lsPackets.front();
		
		bool bRet = m_clsDecodec->Send(pstPacket);
		m_lsPackets.pop_front();
		if (false == bRet){
			mux.unlock();
			msleep(1);
			continue;
		}

		while (false == m_bIsExit)
		{
			AVFrame *pstFrame = m_clsDecodec->Recv();
			
			if (NULL == pstFrame){
				break;
			}
			//��ȥ������δ���ŵ�ʱ��
			m_llPts = m_clsDecodec->m_llPts - m_clsAdoPlay->GetNoPlayMs();
			cout << "AUDIO _llPts = " << m_llPts << endl;
			int iLen = m_clsResample->Resample(pstFrame, pucPcm);
			//������Ƶ
			while (false == m_bIsExit)
			{
				if (iLen <= 0) break;
				//����û�в���
				if (m_clsAdoPlay->GetFree() < iLen || m_bIsPause)
				{
					msleep(1);
					continue;
				}
				m_clsAdoPlay->Write(pucPcm, iLen);
				break;
			}
		}
		mux.unlock();
	}
	delete pucPcm;
}
XAudioThread::XAudioThread()
{
}


XAudioThread::~XAudioThread()
{
	//�ȴ��߳��Ƴ�
	m_bIsExit = true;
	wait();
}
