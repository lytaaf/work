#include "XResample.h"
#include <iostream>

using namespace std;
extern "C"
{
#include <libswresample/swresample.h>
#include <libavcodec/avcodec.h>
}
#pragma comment(lib, "swresample.lib")

 bool XResample::Open(AVCodecParameters *pstCodecPara, bool bIsClearPara)
{
	if (NULL == pstCodecPara)
	{
		cout << "Open:XResample NULL == pstCodecPar !" << endl;
		return false;
	}
	mux.lock();
	int iRet = 0;
	//m_pstSwrCtx = swr_alloc();

	m_pstSwrCtx = swr_alloc_set_opts(m_pstSwrCtx, av_get_default_channel_layout(2),
									(AVSampleFormat)m_enOutForamt,//�����������ʽ 
									pstCodecPara->sample_rate, //����Ĳ�����
									av_get_default_channel_layout(pstCodecPara->channels),//�����ʽ
									(AVSampleFormat)pstCodecPara->format,
									pstCodecPara->sample_rate, 0, 0);
	if (true == bIsClearPara)
		avcodec_parameters_free(&pstCodecPara);
	
	iRet = swr_init(m_pstSwrCtx);
	mux.unlock();
	if (0 != iRet)
	{		
		char szBuf[1024] = {0};
		av_strerror(iRet, szBuf, sizeof(szBuf) - 1);
		cout << "Open ::swr_init error!" << endl;
		return false;
	}

	return true;
}
void XResample::Close()
{
	mux.lock();

	if (m_pstSwrCtx)
		swr_free(&m_pstSwrCtx);
	mux.unlock();
}
int XResample::Resample(AVFrame* pstInFrame, unsigned char *pucOutData)
{
	if (NULL == pstInFrame)
	{
		cout << "Resample :NULL == pstInFrame " << endl;
		return 0;
	}

	if (NULL == pucOutData)
	{
		cout << "Resample :NULL == pucOutData " << endl;
		av_frame_free(&pstInFrame);
		return 0;
	}
	uint8_t *apucData[2] = { NULL, NULL };
	apucData[0] = pucOutData;
	int iLen = swr_convert(m_pstSwrCtx,
							apucData, pstInFrame->nb_samples, //���
							(const uint8_t**)pstInFrame->data, 
							pstInFrame->nb_samples);//����
	
	if (iLen <= 0)
	{
		cout << "Resample::swr_convert " << iLen << endl;
		return iLen;
	}
	 int iOutSize = iLen * pstInFrame->channels * av_get_bytes_per_sample((AVSampleFormat)m_enOutForamt);
	 av_frame_free(&pstInFrame);
	 return iOutSize;
}
XResample::XResample()
{
}


XResample::~XResample()
{
}
