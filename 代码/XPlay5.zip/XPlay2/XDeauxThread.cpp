#include <iostream>
#include "XDeauxThread.h"
#include "XDemu.h"
#include "XAudioThread.h"
#include "XVideoThread.h"

extern "C"
{
#include <libavformat/avformat.h>
}
#include <XDecodec.h>
using namespace std;
void XDeauxThread::Seek(double pos)
{
	Clear();
	DeauxMux.lock();
	bool status = m_bIsPause;
	DeauxMux.unlock();

	SetPause(true);
	DeauxMux.lock();
	if (m_pclsDemu) m_pclsDemu->Seek(pos);
	//ʵ��Ҫ��ʾ��λ��Pts

	long long llSeekPts = pos * m_pclsDemu->m_iTotalTime;
	while (!m_bIsExit)
	{
		//AVPacket *pstPacket = m_pclsDemu->Read();ReadVideo
		AVPacket *pstPacket = m_pclsDemu->ReadVideo();
		if (NULL == pstPacket) break;
		//������뵽seekPts
		if (m_pclsVdoThread->RepaintPts(pstPacket, llSeekPts))
		{
			m_llPts = llSeekPts;
			break;
		}
		

		//bool bRet = m_pclsVdoThread->decode->Send(pstPacket);
		////av_packet_free(&pstPacket);

		//if (false == bRet)
		//	break;

		//AVFrame *ptsFrame = m_pclsVdoThread->decode->Recv();
		//if (NULL == ptsFrame) continue;

		////����λ����ʾ
		//if (ptsFrame->pts >= llSeekPts)
		//{
		//	this->m_llPts = ptsFrame->pts;
		//	m_pclsVdoThread->call->Repaint(ptsFrame);
		//	break;
		//}
		//av_frame_free(&ptsFrame);
	}
	DeauxMux.unlock();
	if (!status)
		SetPause(false);
}

void XDeauxThread::Clear()
{
	DeauxMux.lock();
	if (m_pclsDemu){
		m_pclsDemu->Clear();
	}
	if (NULL != m_pclsVdoThread) m_pclsVdoThread->Clear();
	if (NULL != m_pclsAdoThread) m_pclsAdoThread->Clear();
	DeauxMux.unlock();

}
bool XDeauxThread::Open(const char *pcUrl, IVideoCall *pclsVdoCall)
{
	if (NULL == pcUrl || (pcUrl[0] == 0)){
		return false;
	}
	DeauxMux.lock();


	//�򿪽��װ
	bool bRet = m_pclsDemu->Open(pcUrl);
	if (false == bRet){
		cout << "XDeauxThread :m_pclsDemu->Open(pcUrl) faild;" << endl;
		return false;
	}
	//����Ƶ������ �ʹ����߳�
	bRet = m_pclsVdoThread->Open(m_pclsDemu->CopyVideoPara(), pclsVdoCall, m_pclsDemu->m_iWid, m_pclsDemu->m_iHei);
	if (false == bRet){
		cout << "XDeauxThread :m_pclsVdoThread->Open faild;" << endl;
	}
	bRet = m_pclsAdoThread->Open(m_pclsDemu->CopyAudioPara(),  m_pclsDemu->m_iSampleRate, m_pclsDemu->m_iChannels);
	if (false == bRet){
		cout << "XDeauxThread :m_pclsVdoThread->Open faild;" << endl;
	}
	m_llTotalMs = m_pclsDemu->m_iTotalTime;

	DeauxMux.unlock();
	cout << "XDeauxThread :bRet = " << bRet << endl;
	return bRet;
}


void XDeauxThread::Stop()
{
	m_bIsExit = true;
	wait();
	if (NULL != m_pclsVdoThread) m_pclsVdoThread->Close();
	if (NULL != m_pclsAdoThread) m_pclsAdoThread->Stop();
	DeauxMux.lock();
	delete m_pclsVdoThread;
	delete m_pclsAdoThread;
	m_pclsVdoThread = NULL;
	m_pclsAdoThread = NULL;
	DeauxMux.unlock();
}
void XDeauxThread::Start()
{
	DeauxMux.lock();
	//
	if (NULL == m_pclsDemu) {
		m_pclsDemu = new XDemu();
	}
	if (NULL == m_pclsVdoThread) {
		m_pclsVdoThread = new XVideoThread();
	}
	if (NULL == m_pclsAdoThread) {
		m_pclsAdoThread = new XAudioThread();
	}
	QThread::start();
	if (NULL != m_pclsVdoThread){
		m_pclsVdoThread->start();
	}
	if (NULL != m_pclsAdoThread){
		m_pclsAdoThread->start();
	}
	DeauxMux.unlock();

}
void XDeauxThread::SetPause(bool bIsPause)
{
	DeauxMux.lock();
	
	m_bIsPause = bIsPause;
	if (NULL != m_pclsAdoThread)
		m_pclsAdoThread->SetPause(bIsPause);
	if (NULL != m_pclsVdoThread)
		m_pclsVdoThread->SetPause(bIsPause);

	DeauxMux.unlock();
}
void XDeauxThread::run()
{
	while (false == m_bIsExit)
	{
	
		DeauxMux.lock();
		if (m_bIsPause){
			DeauxMux.unlock();
			msleep(5);
			continue;
		}
		if (NULL == m_pclsDemu){
			DeauxMux.unlock();
			msleep(6);
			continue;
		}
		
	
		//����Ƶͬ��
		if (m_pclsAdoThread && m_pclsVdoThread){
			m_llPts = m_pclsAdoThread->m_llPts;
			m_pclsVdoThread->m_llSynPts = m_pclsAdoThread->m_llPts;
		}

		AVPacket *pstPacket =  m_pclsDemu->Read();
		if (NULL == pstPacket)
		{
			DeauxMux.unlock();
			msleep(6);
			continue;
		}
		if (m_pclsDemu->IsAudio(pstPacket))
		{
			//��֤��Ӧ����
			if (NULL !=  m_pclsAdoThread)
				m_pclsAdoThread->Push(pstPacket);
		} 
		else
		{
			if (NULL != m_pclsVdoThread)
				m_pclsVdoThread->Push(pstPacket);
		}

		DeauxMux.unlock();
		msleep(1);
	}

}
XDeauxThread::XDeauxThread()
{
}


XDeauxThread::~XDeauxThread()
{
	m_bIsExit = true;
	wait();
}
