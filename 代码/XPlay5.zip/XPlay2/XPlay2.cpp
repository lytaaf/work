#include "XPlay2.h"
#include <QFileDialog>
#include <QDebug>
#include "XDeauxThread.h"
#include <QMessageBox>
//ʹ��ָ�� ���캯���ĵ��ò���Ӱ���ʼ��

static XDeauxThread dt;
XPlay2::XPlay2(QWidget *parent)
	: QWidget(parent)
{
	ui.setupUi(this);
	dt.Start();
	startTimer(40);
}
XPlay2::~XPlay2()
{
	dt.Stop();
}
void XPlay2::timerEvent(QTimerEvent *e)
{
	long long total = dt.m_llTotalMs;
	if (total > 0)
	{
		double pos = (double)dt.m_llPts / (double)total;
		int v = ui.playPos->maximum() * pos;
		ui.playPos->setValue(v);
	}
}
void XPlay2::resizeEvent(QResizeEvent *e)
{
	ui.playPos->move(50, this->height() - 100);
	ui.playPos->resize(this->width() - 200 , ui.playPos->height());
	ui.OpenFile->move(100, this->height() - 150);
	ui.isplay->move(ui.OpenFile->x() + ui.OpenFile->width() + 10, ui.OpenFile->y());
	ui.video->resize(this->size());

}
void XPlay2::SetPause(bool isPlay)
{
	if (isPlay)
		ui.isplay->setText(QString::fromLocal8Bit("�� ��"));
	else
		ui.isplay->setText(QString::fromLocal8Bit("�� ͣ"));

}
void XPlay2::mouseDoubleClickEvent(QMouseEvent *e)
{
	if (isFullScreen())
	{
		this->showNormal();
	}
	else
	{
		this->showFullScreen();
	}

}

void XPlay2::PlayOrPause()
{
	bool bIsPause = !dt.m_bIsPause;
	SetPause(bIsPause);
	dt.SetPause(bIsPause);
}
void XPlay2::OpenFile()
{
	//ѡ���ļ�
	QString name =  QFileDialog::getOpenFileName(this, QString::fromLocal8Bit("ѡ����Ƶ�ļ�"));
	if (name.isEmpty()) return;

	this->setWindowTitle(name);
	qDebug() << name;
	if (!dt.Open(name.toLocal8Bit(), ui.video))
	{
		QMessageBox::information(0, "error", "open file faild");
		return;
	}
	SetPause(dt.m_bIsPause);
}

void XPlay2::SliderPress()
{
	m_bIsSliderPress = true;
}

void XPlay2::SliderRelease()
{
	m_bIsSliderPress = false;
	double pos = 0.0;
	pos = (double)ui.playPos->value() / (double)ui.playPos->maximum();
	dt.Seek(pos);
}