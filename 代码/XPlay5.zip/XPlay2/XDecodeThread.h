#pragma once
struct AVPacket;
struct AVCodecParameters;
class XDecodec;
#include <list>
#include <mutex>
#include <QThread>
#include "IVideoCall.h"
class XDecodeThread :public QThread
{
public:
	XDecodeThread();
	virtual ~XDecodeThread();
	virtual void Push(AVPacket *pkt);
	virtual AVPacket* Pop();

	virtual void Clear();
	virtual void Close();
	bool isExit = false;
	int maxList = 100;
	XDecodec *decode = 0;
protected:
	std::list <AVPacket *> packs;
	std::mutex mux;
	
};

