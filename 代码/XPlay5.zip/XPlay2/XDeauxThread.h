#pragma once
#include <QThread>
#include "IVideoCall.h"
#include <mutex>
class IVideoCall;
class XDemu;
class XVideoThread;
class XAudioThread;
class XDeauxThread: public QThread
{
public:
	virtual bool Open(const char *pcUrl, IVideoCall *pclsVdoCall);
	//�����������Ե��߳�
	virtual void Start();
	virtual void Stop();
	virtual void Clear();

	virtual void Seek(double pos);
	void run();
	XDeauxThread();
	virtual ~XDeauxThread();
	bool m_bIsExit = false;
	long long m_llPts = 0;
	long long m_llTotalMs = 0;
	bool m_bIsPause = false;
	void SetPause(bool bIsPause);
protected:
	std::mutex DeauxMux;
	IVideoCall *m_pclsVdoCall = NULL;
	XDemu *m_pclsDemu = NULL;
	XVideoThread *m_pclsVdoThread = NULL;
	XAudioThread *m_pclsAdoThread = NULL;
};

