#include "XDecodec.h"
#include <iostream>
extern "C"
{
#include "libavformat\avformat.h"
#include "libavcodec\avcodec.h"
}
#pragma comment(lib, "avformat.lib")
#pragma comment(lib, "avcodec.lib")
#pragma comment(lib, "avutil.lib")

using namespace std;
 void XFreePacket(AVPacket **pstPacket)
{
	if (!pstPacket ||  !(*pstPacket)) return;
	av_packet_free(pstPacket);
}

void XFreeFrame(AVFrame **pstFrame)
{
	if (!pstFrame || !(*pstFrame)) return;
	av_frame_free(pstFrame);
}
void XDecodec::Clear()
{
	m_CodecMutex.lock();
	if (NULL != m_pstCodecCtx)
	{
		avcodec_flush_buffers(m_pstCodecCtx);
	}
	m_CodecMutex.unlock();
	return;
}
void XDecodec::Close()
{
	m_CodecMutex.lock();
	if (NULL != m_pstCodecCtx)
	{
		avcodec_close(m_pstCodecCtx);
		avcodec_free_context(&m_pstCodecCtx);
	}
	m_llPts = 0;
	m_CodecMutex.unlock();
	return;
}
bool XDecodec::Open(AVCodecParameters *pstCodecPara)
{
	if (NULL == pstCodecPara)
	{
		return false;
	}
	Close();
	AVCodec *pstCodec = avcodec_find_decoder(pstCodecPara->codec_id);
	if (NULL == pstCodec)
	{
		avcodec_parameters_free(&pstCodecPara);
		printf("NULL == pstVdoCodec");
		return false;
	}
	printf("find the VdoavCodec = %d\n", pstCodecPara->codec_id);
	//����������������
	m_CodecMutex.lock();
	m_pstCodecCtx = avcodec_alloc_context3(pstCodec);
	//�򿪽�������������
	avcodec_parameters_to_context(m_pstCodecCtx, pstCodecPara);
	//���װ
	//8�߳̽���
	m_pstCodecCtx->thread_count = 8;
	//�򿪽�����
	int iRet = avcodec_open2(m_pstCodecCtx, 0, 0);
	if (0 != iRet)
	{
		avcodec_free_context(&m_pstCodecCtx);
		//avcodec_parameters_free(&pstCodecPara);
		m_CodecMutex.unlock();
		char szBuf[1024] = { 0 };
		av_strerror(iRet, szBuf, sizeof(szBuf) - 1);
		cout << "avcodec_open2 faild" << endl;
		return false;
	}
	cout << "avcodec_open2 success" << endl;
	m_CodecMutex.unlock();
	return true;
}

bool XDecodec::Send(AVPacket *pstPacket)
{
	if ((NULL == pstPacket) || (0 >= pstPacket->size) || (NULL == pstPacket->data))
	{
		cout << "NULL == pstPacket) || (pstPacket->size) || (NULL == pstPacket->data"<< endl;
		return false;
	}


	m_CodecMutex.lock();
	if (NULL == m_pstCodecCtx)
	{
		cout << "Send NULL == m_pstCodecCt " << endl;
		m_CodecMutex.unlock();
		return false;
	}

	int iRet = avcodec_send_packet(m_pstCodecCtx, pstPacket);
	m_CodecMutex.unlock();
	av_packet_free(&pstPacket);
	if (0 != iRet)
	{
		cout << "Send avcodec_send_packet error " << endl;
		return false;
	}
	return true;
}

//��ȡ����֮������ݣ� һ��send ���ܶ��recv ��ȡ�����е����� send null��recv���
//ÿ�θ���һ���ɵ������ͷ�av_frame_free();

AVFrame* XDecodec::Recv()
{
	m_CodecMutex.lock();
	if (NULL == m_pstCodecCtx)
	{
		cout << "Recv NULL == m_pstCodecCtx " << endl;
		m_CodecMutex.unlock();
		return NULL;
	}
	
	AVFrame *pstFrame = av_frame_alloc();
	int iRet = avcodec_receive_frame(m_pstCodecCtx, pstFrame);
	m_CodecMutex.unlock();
#if 1
	if (0 != iRet)
	{
		char szBuf[1024] = { 0 };
		if (true == m_bIsAudio)
		{
			cout << "Recv Audio avcodec_receive_frame error " << endl;
			av_strerror(iRet, szBuf, sizeof(szBuf) - 1);
		}
		else
		{
			cout << "Recv Video avcodec_receive_frame error " << endl;
			av_strerror(iRet, szBuf, sizeof(szBuf) - 1);
		}
		printf("Recv Error :%s\n", szBuf);
		av_frame_free(&pstFrame);
		return NULL;
	}
	m_llPts = pstFrame->pts;
#endif
	return pstFrame;
}
XDecodec::XDecodec()
{
}


XDecodec::~XDecodec()
{
}
